
####################################################################

###### ORIGANOVA rel. 2.0
###### examples 

####################################################################

## Chapter 1

10*sqrt(2)/4

win.graph()
hist(c(2,3,3,5,2),breaks=0:6,density=20)

(10^308)==(10^308-1)


x<- c( 4.37348,19.2912,	20.7221,12.1345,14.8025,
	22.2741, 12.2369,	15.5669,18.0976, 17.748,
 	14.5603,13.6388, 8.89321, 12.5463,15.3694,
 	17.5275,13.7957,19.9823,14.256,15.1928,11.2705,
	20.9492,14.1695,23.5501,14.5677,15.3169,10.7054,
 	14.4311, 16.1116,	13.4388)

summary(x)


win.graph()
hist(x,density=20)


win.graph()
hist(x,nclass=10,density=20)


win.graph()
hist(x,nclass=10,ylim=c(0,25),density=20)



####################################################################

## Chapter 2

(d<-c(3,3,3,3,3)-c(2,3,3,5,2))

(d<-3-c(2,3,3,5,2))

mean(d)

sum(d)

sum(d^2)/4

sqrt(sum(d^2)/4)

sd(c(2,3,3,5,2))



####################################################################

## Chapter 3

Ta<-c(52,52,60,59,50,55,57,57,57,56,52,57,55,54,51)

win.graph()
boxplot(Ta)

Ta<-c(Ta,100)

win.graph()
boxplot(Ta)


x1<-1:20
y1<-1.2*x1+7
win.graph()
plot(x1,y1)
cor(x1,y1)

x2<-rnorm(20)
y2<-rnorm(20)
win.graph()
plot(x2,y2)
cor(x2,y2)

y3<-y1+rnorm(20,mean=0,sd=0.5)
win.graph()
plot(x1,y3)
cor(x1,y3)



####################################################################

## Chapter 4


x<--40:40
x<-x/10
win.graph()
plot(x,dnorm(x),type="l")
title(main="Normal Distribution")


pnorm(-3:3)

pnorm(-3:3,lower.tail=TRUE)

pnorm(-3:3,lower.tail=FALSE)

1-0.001349898*2


pesi<-c(2995, 3010, 3007, 2999, 2998, 2994, 3006,
  3003, 2998, 2992, 3002, 3004, 3005, 2997, 3002,
  3003, 3006, 3002, 3009, 3008, 3000, 3001, 2995,
  2990, 3011)


mean(pesi)

sd(pesi)

mean(pesi)-3*sd(pesi)
mean(pesi)+3*sd(pesi)


####################################################################

## Chapter 5

## variable pesi is defined in Chapter 4 NB

win.graph()
par(mfrow=c(2,1))
boxplot(pesi,horizontal=TRUE)
xx<-2990+1:20
plot(xx,dnorm(xx, mean=mean(pesi),sd=sd(pesi)),
type="l",ylab="")



####################################################################

## Chapter 6

samples<-c(0.01, 0.015, 0.02, 0.008, 0.022)

mean(samples)

sd(samples)

sd(samples)/sqrt(5)

weight<-c(2, 3, 3, 5, 2, 3, 3, 2, 2, 3, 2, 3, 1, 2,
 3, 3, 4, 3, 4, 2, 4, 3, 1, 5, 1, 3, 1, 2, 2, 2, 4,
 3, 2, 2, 4, 3, 5, 3, 2, 1, 4, 3, 2, 3, 2, 3, 1, 4,
 5, 1, 1, 3, 3, 1, 2, 2, 1, 4, 3, 2, 2, 2, 2, 2, 3,
 4, 2, 2, 2, 1, 2, 2, 3, 2, 2, 3, 4, 1, 2, 3, 3, 4,
 2, 2, 2, 1, 3, 3, 1, 4, 1, 2, 1, 2, 1, 2, 2, 4, 2,
 2)

mean(weight)
sd(weight)
sd(weight)/sqrt(length(weight))


win.graph()
hist(weight)
plot(function(x) length(weight)*
 dnorm(x,mean=mean(weight),sd=sd(weight)),
 from=1,to=5,add=TRUE) 




####################################################################

## Chapter 7

A<- c(72, 82, 65, 83, 50, 61, 83, 68, 52, 75)
mean(A)
G<- c(89, 71, 76, 81, 75, 79, 60, 62, 70, 61)
mean(G)

t.test(A,G)


M<- c(5, 23, 18, 9, 12, 25, 19, 14)
N<- c(7, 24, 19, 11, 15, 25, 20, 15)

t.test(M,N)

t.test(M,N,paired=TRUE)


####################################################################

## Chapter 8


Bill<-c(10, 12, 15, 18, 13, 9, 11, 10, 16, 14)

Bull<-c(8.0, 10.2, 13.5, 16.8, 11.3, 6.9, 9.1, 8.0, 14.6, 12.4)

cbind(Bill,Bull)

cor(Bill,Bull)

Bill*1.1-3

win.graph()
plot(Bill,Bull)

# remember to install package epiR

require(epiR)

epi.ccc(Bill,Bull)

bla<-epi.ccc(Bill,Bull)
bla$rho.c
bla$rho.c$lower

cf.lin<-function(a,b){
# Lin CCC (Concordance Correlation Coefficient)
n<-length(a)
ma<-mean(a)
mb<-mean(b)
sa<-sd(a)
sb<-sd(b)  
r<-cor(a,b)                                 # correlation coefficient
c<-(2*sa*sb)/(sa^2+sb^2+(n/(n-1))*(ma-mb)^2)       # bias correction
cat("r=",r,"\n")
cat("CF=",c,"\n") 
cat("CCC=",(c*r),"\n")                                        # CCC
}


cf.lin(Bill,Bull)



####################################################################

## Chapter 9  

Y<- c( 89, 71, 76, 81, 75, 79, 60, 62, 70, 61,
 72, 82, 65, 83, 50, 61, 83, 68, 52, 75, 79, 52,
 80, 68, 61, 68, 74, 71, 76, 73)

A<-rep(c("0G","1A","2B"),each=10) 

cbind(Y,A)

A<-as.factor(A)  
 
summary(aov(Y~A))

anova(lm(Y~A))  # is a different way to get the same result


M<-rep(mean(Y),length(Y))
P<-tapply(Y,A,mean)
P<-rep(P,each=10)

D<-Y-M

E<-Y-P 

T<-P-M 

E<-D-T ## consequently

(Y-P)==(D-T)

sum(D^2)
sum(T^2)
sum(E^2) 

sum(D^2)-sum(T^2)  ## is the same

(56.46667/2)/(2804.9/27)

pf(0.2718,2,27,lower.tail=FALSE)

1-pf(0.2718,2,27)

# a look to the data
round(cbind(Y,M,D,P,T,E),2)
					

####################################################################

## Chapter 10

getwd()

dogs<-read.delim("dogs.txt")

attach(dogs)

cor(Si,Tg)

cor(Si,H)

summary(lm(Si~H))

-1/sqrt(2)

91.88336+2*1.94201

-0.61746 - 0.07371*2

win.graph()
plot(Tg,Si)

win.graph()
plot(H,Si)
abline(lm(Si~H))



X<-cbind(1,H)

qr.solve(X,Si)

(solve(t(X) %*% X)) %*% (t(X) %*% Si)


####################################################################

## Appendix C

win.graph()
plot(x=1,y=1,xlim=c(0,20),ylim=c(0,20),type="n")
abline(7,1.2)

abline(8,1.2,lty=2)
abline(6,1.2,lty=2)







 

